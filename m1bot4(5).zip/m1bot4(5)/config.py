# config.py

# --- Telegram Configuration ---
# আপনার বটের টোকেন এখানে দিন
TELEGRAM_BOT_TOKEN = "7773878549:AAGIirDcmGKqMp21vR9fDk_yNgGGjuqgsrQ" 
# আপনার ব্যক্তিগত ইউজার আইডি এখানে দিন। বট আপনাকে গুরুত্বপূর্ণ নোটিফিকেশন পাঠাবে।
# @userinfobot থেকে আপনার আইডি পেতে পারেন।
ADMIN_USER_ID = 5172723202  # <<<<<<<<<<<<<<< আপনার ইউজার আইডি এখানে দিন

# --- API Keys ---
# Twelve Data API কী-গুলোর তালিকা
BASE_TWELVE_DATA_API_KEYS = [
   'f134e2148da043f1a97fc52d9e134123',
    '8734a7db9f434f32949481a5deabd32a',
    '062bb1ba02b84dcb9ec4fcdbd1850bd7',
    # আরও কী যোগ করতে পারেন
]

# --- Database ---
DB_FILE = "trading_bot.db"

# --- Model Files ---
MODEL_MACRO_PATH = 'forex_model_macro.pkl'
MODEL_MICRO_PATH = 'forex_model_micro.pkl'

# --- Trading Logic ---
# কোন কোন মার্কেট সাপোর্ট করা হবে
SUPPORTED_MARKETS = {
    "Forex": ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD"],
    "Crypto": ["BTC/USD", "ETH/USD"],
    "Commodities": ["XAU/USD"],
}