# ml_model.py
import pandas as pd
import pandas_ta as ta
import xgboost as xgb
from sklearn.model_selection import train_test_split
import joblib
import os
import numpy as np
from database import get_training_data
from config import MODEL_MACRO_PATH, MODEL_MICRO_PATH

def prepare_features(df: pd.DataFrame) -> (pd.DataFrame, pd.DataFrame):
    df['body_size'] = abs(df['close'] - df['open'])
    df['upper_shadow'] = df['high'] - np.maximum(df['open'], df['close'])
    df['lower_shadow'] = np.minimum(df['open'], df['close']) - df['low']
    df['price_change'] = df['close'].diff()
    if 'volume' in df.columns and not df['volume'].isnull().all():
        df['volume_change'] = df['volume'].diff()

    # Pandas-TA ব্যবহার করে ইন্ডিকেটর যোগ করা
    df.ta.adx(append=True)
    df.ta.atr(append=True)
    df.ta.rsi(length=14, append=True)
    df.ta.stoch(k=14, d=3, append=True)
    df.ta.bbands(length=20, append=True)
    df.ta.macd(fast=12, slow=26, append=True)
    
    # EMA ক্রসওভার
    df['ema_fast'] = df.ta.ema(length=8)
    df['ema_slow'] = df.ta.ema(length=21)
    df['ema_cross'] = df['ema_fast'] - df['ema_slow']

    # সব NaN ভ্যালু বাদ দেওয়া
    df.dropna(inplace=True)
    
    # ফিচার কলামের তালিকা
    feature_columns = [col for col in df.columns if col.isupper() or col in ['body_size', 'upper_shadow', 'lower_shadow', 'price_change', 'volume_change', 'ema_cross']]
    existing_features = [col for col in feature_columns if col in df.columns]
    
    if not existing_features or df.empty:
        return pd.DataFrame()
        
    return df[existing_features]

def train_and_evaluate_model(model_type: str, model_path: str):
    """ডেটাবেস থেকে পাওয়া ফলাফলের ওপর ভিত্তি করে মডেলকে প্রশিক্ষণ দেয়।"""
    print(f"\n--- Training {model_type.capitalize()} Model from Database Feedback ---")
    
    X, y = get_training_data(model_type)
    
    if X.empty or y.empty or len(X) < 50:
        print(f"Not enough historical data ({len(X)} samples) to train {model_type} model. Need at least 50.")
        return False
        
    print(f"Training with {len(X)} samples.")
    
    # ক্লাসের ভারসাম্যহীনতা মোকাবেলা
    scale_pos_weight = (y == 0).sum() / (y == 1).sum() if (y == 1).sum() > 0 else 1
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
    
    model = xgb.XGBClassifier(
        objective='binary:logistic',
        n_estimators=200,          # ওভারফিটিং কমাতে কমানো হয়েছে
        learning_rate=0.05,        # শেখার হার কমানো হয়েছে
        max_depth=4,               # গাছের গভীরতা কমানো হয়েছে
        subsample=0.7,
        colsample_bytree=0.7,
        use_label_encoder=False,
        eval_metric='logloss',
        early_stopping_rounds=15,  # আগে থামার জন্য
        scale_pos_weight=scale_pos_weight, # ভারসাম্যহীনতা ঠিক করতে
        random_state=42,
        n_jobs=-1
    )
    
    model.fit(X_train, y_train, eval_set=[(X_test, y_test)], verbose=False)
    accuracy = model.score(X_test, y_test)
    print(f"Model validation accuracy: {accuracy:.2%}")
    
    if accuracy > 0.55: # শুধুমাত্র যদি মডেলটি ৫০% এর চেয়ে ভালো কাজ করে তবেই সেভ হবে
        joblib.dump(model, model_path)
        print(f"Model saved to {model_path}")
        return True
    else:
        print("Model performance is below threshold (55%). Not saving the new model.")
        return False

def predict_signal(df: pd.DataFrame, model_path: str):
    """প্রশিক্ষিত মডেল ব্যবহার করে সিগন্যাল প্রেডিক্ট করে এবং ফিচারগুলোও রিটার্ন করে।"""
    if not os.path.exists(model_path):
        return -1, pd.DataFrame() # মডেল পাওয়া যায়নি
    
    features = prepare_features(df)
    if features.empty:
        return -2, pd.DataFrame() # ফিচার তৈরি করা যায়নি

    last_features = features.iloc[[-1]] # প্রেডিকশনের জন্য শেষ সারি
    model = joblib.load(model_path)
    prediction = model.predict(last_features)[0]
    
    return prediction, last_features