# train.py
import asyncio
import pandas as pd
from analysis import fetch_market_data, load_api_keys
from ml_model import train_model
from database import initialize_database
from handlers import MARKETS

async def train_universal_model(target_type: str, model_path: str, interval: str):
    print(f"\n--- Training Universal {target_type.capitalize()} Model ({interval} Data) ---")
    all_assets = [asset for category in MARKETS.values() for asset in category]
    training_markets = sorted(list(set(all_assets)))
    tasks = [asyncio.create_task(fetch_market_data(m, interval, 5000)) for m in training_markets]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    all_fetched_data = [res for res in results if isinstance(res, pd.DataFrame) and not res.empty]
    
    if not all_fetched_data:
        print(f"CRITICAL: Could not fetch data for {target_type} model.")
        return
        
    combined_df = pd.concat(all_fetched_data, ignore_index=True)
    combined_df.drop_duplicates(subset=['datetime', 'close'], keep='first', inplace=True)
    
    print(f"Total unique rows for {target_type} model: {len(combined_df)}")
    if len(combined_df) > 1000:
        train_model(combined_df, model_path, target_type=target_type)

async def main():
    from ml_model import MODEL_MACRO, MODEL_MICRO
    await train_universal_model(target_type='macro', model_path=MODEL_MACRO, interval='5min')
    await train_universal_model(target_type='micro', model_path=MODEL_MICRO, interval='1min')
    print("\n--- All manual training processes finished ---")

if __name__ == "__main__":
    initialize_database()
    load_api_keys()
    asyncio.run(main())
