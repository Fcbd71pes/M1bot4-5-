# handlers.py
import asyncio
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from config import ADMIN_USER_ID, SUPPORTED_MARKETS
from database import (
    check_user_access, grant_access_to_user, add_api_key,
    get_pending_users, get_all_users, set_ban_status
)
from analysis import analyze_market_for_signal, load_api_keys

user_jobs = {}

async def auto_signal_callback(context: ContextTypes.DEFAULT_TYPE):
    job = context.job
    user_id, selected_markets = job.data["user_id"], job.data["markets"]

    try:
        results = await asyncio.gather(*[analyze_market_for_signal(m) for m in selected_markets])
        
        trade_time = (datetime.utcnow() + timedelta(minutes=1)).strftime("%H:%M")
        final_message = f"🔮 <b>Dual-Momentum Signals for {trade_time} UTC</b> 🔮\n"
        
        valid_signals = [res for res in results if "WAIT" not in res["finalSignal"] and "ERROR" not in res["finalSignal"]]

        if not valid_signals:
            return # কোনো সিগন্যাল না থাকলে মেসেজ পাঠানোর দরকার নেই

        for res in valid_signals:
            reasons = ", ".join(res.get("reasons", []))
            final_message += f"\n<b>{res['market']}: {res['finalSignal']}</b>\n<pre>Confirmation: {reasons}</pre>\n"

        app_url = "https://market-qx.pro/en/sign-up?lid=1377542"
        keyboard = [[InlineKeyboardButton("🚀 Open Trading App", url=app_url)]]
        await context.bot.send_message(
            chat_id=user_id, text=final_message, parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(keyboard), disable_web_page_preview=True
        )
    except Exception as e:
        print(f"Error in auto_signal_callback for user {user_id}: {e}")
        # Error message is suppressed for users to avoid spam

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_details = {"first_name": user.first_name, "username": user.username}
    has_access, is_new, is_banned = check_user_access(user.id, user_details)

    if is_banned:
        await update.message.reply_text("🚫 You have been banned from using this bot.")
        return

    if has_access:
        await update.message.reply_text(
            "👋 Welcome back to the Self-Learning Bot!\n\n/autosignal - Start signals\n/stopsignal - Stop signals"
        )
    else:
        await update.message.reply_text("Welcome! Your account is pending admin approval.")
        if is_new and ADMIN_USER_ID:
            admin_msg = f"🔔 <b>New User Request</b>\n<b>Name:</b> {user.full_name}\n<b>ID:</b> <code>{user.id}</code>\n\nTo approve, use /approve {user.id}"
            await context.bot.send_message(chat_id=ADMIN_USER_ID, text=admin_msg, parse_mode=ParseMode.HTML)

async def autosignal_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    has_access, _, is_banned = check_user_access(user_id, {})

    if is_banned or not has_access:
        await update.message.reply_text("🚫 Access denied.")
        return

    context.user_data["selections"] = []
    buttons = []
    for category, markets in SUPPORTED_MARKETS.items():
        buttons.append([InlineKeyboardButton(f"--- {category} ---", callback_data="ignore")])
        row = [InlineKeyboardButton(m, callback_data=f"m_{m}") for m in markets]
        buttons.append(row)

    buttons.append([InlineKeyboardButton("▶️ Start Auto-Signals", callback_data="start_job")])
    await update.message.reply_text("Select markets for automatic signals:", reply_markup=InlineKeyboardMarkup(buttons))

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    
    if query.data == 'ignore': return

    if query.data.startswith("m_"):
        market = query.data.split("_")[1]
        selections = context.user_data.get("selections", [])
        if market in selections: selections.remove(market)
        else: selections.append(market)
        context.user_data["selections"] = selections

        buttons = []
        for category, markets in SUPPORTED_MARKETS.items():
            buttons.append([InlineKeyboardButton(f"--- {category} ---", callback_data="ignore")])
            row = [InlineKeyboardButton(f"{'✅ ' if m in selections else ''}{m}", callback_data=f"m_{m}") for m in markets]
            buttons.append(row)
        buttons.append([InlineKeyboardButton("▶️ Start Auto-Signals", callback_data="start_job")])
        try:
            await query.edit_message_reply_markup(reply_markup=InlineKeyboardMarkup(buttons))
        except Exception: pass

    elif query.data == "start_job":
        selected_markets = context.user_data.get("selections", [])
        if not selected_markets:
            await query.answer("Please select at least one market.", show_alert=True)
            return

        if user_id in user_jobs:
            user_jobs[user_id].schedule_removal()

        job = context.job_queue.run_repeating(
            auto_signal_callback, interval=60, first=5,
            data={"user_id": user_id, "markets": selected_markets}
        )
        user_jobs[user_id] = job
        await query.edit_message_text(
            f"✅ Self-learning signals started for: <b>{', '.join(selected_markets)}</b>.\nBot will now send high-probability signals and learn from outcomes.",
            parse_mode=ParseMode.HTML
        )

# ... আগের মতো বাকি অ্যাডমিন হ্যান্ডলারগুলো যোগ করুন ...
# stopsignal, addkey, approve, etc.
async def stopsignal_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id in user_jobs:
        user_jobs[user_id].schedule_removal()
        del user_jobs[user_id]
        await update.message.reply_text("⏹️ Automatic signals have been stopped.")
    else:
        await update.message.reply_text("No automatic signals are currently running.")


async def addkey_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    key = " ".join(context.args)
    if not key:
        await update.message.reply_text(
            "Usage: <code>/addkey YOUR_API_KEY_HERE</code>", parse_mode=ParseMode.HTML
        )
        return
    if add_api_key(key, update.effective_user.id):
        load_api_keys()
        await update.message.reply_text(
            "✅ Thank you! Your API key has been added and activated."
        )


# --- অ্যাডমিন কমান্ড ---
async def approve_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_USER_ID:
        return
    try:
        user_to_approve = int(context.args[0])
        if grant_access_to_user(user_to_approve):
            await update.message.reply_text(f"✅ User {user_to_approve} approved.")
            await context.bot.send_message(
                chat_id=user_to_approve,
                text="🎉 Congratulations! Your account has been approved. Use /autosignal to start.",
            )
    except (IndexError, ValueError):
        await update.message.reply_text("Usage: /approve <user_id>")


async def pending_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_USER_ID: return
    pending = get_pending_users()
    if not pending:
        await update.message.reply_text("No users are pending approval.")
        return
    message = "<b>Pending Users:</b>\n\n"
    for user in pending:
        message += f"<b>Name:</b> {user['firstName']}\n<b>ID:</b> <code>{user['id']}</code>\n/approve {user['id']}\n\n"
    await update.message.reply_text(message, parse_mode=ParseMode.HTML)


async def users_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_USER_ID: return
    all_users = get_all_users()
    if not all_users:
        await update.message.reply_text("No users found in the database.")
        return
    message = "👥 <b>User List</b> 👥\n\n"
    for user in all_users:
        status = ("🟢 Approved" if user["access"] else ("🔴 Banned" if user["banned"] else "🟡 Pending"))
        name = user["name"] if user["name"] else "N/A"
        message += f"<b>Name:</b> {name}\n<b>ID:</b> <code>{user['id']}</code>\n<b>Status:</b> {status}\n\n"
    await update.message.reply_text(message, parse_mode=ParseMode.HTML)


async def ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_USER_ID: return
    try:
        user_id_to_ban = int(context.args[0])
        set_ban_status(user_id_to_ban, True)
        if user_id_to_ban in user_jobs:
            user_jobs[user_id_to_ban].schedule_removal()
            del user_jobs[user_id_to_ban]
        await update.message.reply_text(f"🔴 User <code>{user_id_to_ban}</code> has been banned.", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await update.message.reply_text("Usage: /ban <user_id>")


async def unban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_USER_ID: return
    try:
        user_id_to_unban = int(context.args[0])
        set_ban_status(user_id_to_unban, False)
        await update.message.reply_text(f"🟢 User <code>{user_id_to_unban}</code> has been unbanned.", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await update.message.reply_text("Usage: /unban <user_id>")