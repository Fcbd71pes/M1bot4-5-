# analysis.py
import httpx
import pandas as pd
from ml_model import predict_signal
from database import log_signal, get_all_user_api_keys
from config import BASE_TWELVE_DATA_API_KEYS, MODEL_MACRO_PATH, MODEL_MICRO_PATH

API_KEYS = []
current_api_key_index = 0

def load_api_keys():
    global API_KEYS
    base_keys = BASE_TWELVE_DATA_API_KEYS
    user_keys = get_all_user_api_keys()
    API_KEYS = list(set(base_keys + user_keys))
    print(f"Loaded {len(API_KEYS)} unique API keys.")

def get_api_key():
    global current_api_key_index
    if not API_KEYS: raise ValueError("No API Keys available.")
    key = API_KEYS[current_api_key_index]
    current_api_key_index = (current_api_key_index + 1) % len(API_KEYS)
    return key

async def fetch_market_data(symbol: str, interval: str, output_size: int):
    api_key = get_api_key()
    url = f"https://api.twelvedata.com/time_series?symbol={symbol}&interval={interval}&outputsize={output_size}&apikey={api_key}"
    async with httpx.AsyncClient() as client:
        try:
            r = await client.get(url, timeout=20.0)
            r.raise_for_status()
            data = r.json()
            if data.get('status') != 'ok' or 'values' not in data:
                raise ValueError(f"API Error for {symbol}: {data.get('message', 'No data')}")
            df = pd.DataFrame(data['values']).iloc[::-1].reset_index(drop=True)
            df['datetime'] = pd.to_datetime(df['datetime'])
            for col in ['open', 'high', 'low', 'close', 'volume']:
                if col in df.columns: df[col] = pd.to_numeric(df[col], errors='coerce')
            return df
        except (httpx.RequestError, ValueError) as e:
            print(f"Error fetching data for {symbol} with key ending in ...{api_key[-4:]}: {e}")
            return None

async def analyze_market_for_signal(market: str):
    try:
        data_5m = await fetch_market_data(market, '5min', 200)
        data_1m = await fetch_market_data(market, '1min', 200)

        if data_5m is None or data_1m is None:
            return {"market": market, "finalSignal": "ERROR ❌", "error": "Data fetch failed"}

        macro_prediction, macro_features = predict_signal(data_5m, MODEL_MACRO_PATH)
        micro_prediction, micro_features = predict_signal(data_1m, MODEL_MICRO_PATH)
        
        entry_price = data_1m.iloc[-1]['close']

        if macro_prediction == 1 and micro_prediction == 1:
            log_signal(market, "CALL", entry_price, macro_features, micro_features)
            return {"market": market, "finalSignal": "CALL 🟢", "reasons": ["Strong Upward Momentum"]}
        
        if macro_prediction == 0 and micro_prediction == 0:
            log_signal(market, "PUT", entry_price, macro_features, micro_features)
            return {"market": market, "finalSignal": "PUT 🔴", "reasons": ["Strong Downward Momentum"]}

        return {"market": market, "finalSignal": "WAIT 🟡", "reasons": ["Mixed Signals"]}

    except Exception as e:
        print(f"Critical error in analysis for {market}: {repr(e)}")
        return {"market": market, "finalSignal": "ERROR ❌", "error": repr(e)}