# database.py
import sqlite3
import pandas as pd
from config import DB_FILE

def initialize_database():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        # ইউজার টেবিল
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY, first_name TEXT, username TEXT,
                has_access BOOLEAN NOT NULL DEFAULT 0, is_banned BOOLEAN NOT NULL DEFAULT 0
            )
        ''')
        # API কী টেবিল
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS api_keys (
                key TEXT PRIMARY KEY, added_by_user_id INTEGER,
                added_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        # সিগন্যাল লগ টেবিল
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS signal_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                market TEXT,
                signal_type TEXT, -- 'CALL' or 'PUT'
                entry_price REAL,
                outcome_price REAL,
                is_correct INTEGER DEFAULT -1 -- -1: Pending, 0: False, 1: True
            )
        ''')
        # **নতুন টেবিল:** সিগন্যাল দেওয়ার সময়কার ফিচারগুলো সংরক্ষণ করার জন্য
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS market_features (
                signal_id INTEGER,
                model_type TEXT, -- 'macro' or 'micro'
                feature_name TEXT,
                feature_value REAL,
                PRIMARY KEY (signal_id, model_type, feature_name),
                FOREIGN KEY (signal_id) REFERENCES signal_logs(id)
            )
        ''')
    print("Database and all tables are ready.")

def log_signal(market, signal_type, entry_price, macro_features, micro_features):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO signal_logs (market, signal_type, entry_price) VALUES (?, ?, ?)",
            (market, signal_type, entry_price)
        )
        signal_id = cursor.lastrowid
        
        # ফিচারগুলো সেভ করা হচ্ছে
        features_to_save = []
        if not macro_features.empty:
            for col in macro_features.columns:
                features_to_save.append((signal_id, 'macro', col, macro_features.iloc[0][col]))
        if not micro_features.empty:
            for col in micro_features.columns:
                features_to_save.append((signal_id, 'micro', col, micro_features.iloc[0][col]))
        
        cursor.executemany(
            "INSERT INTO market_features (signal_id, model_type, feature_name, feature_value) VALUES (?, ?, ?, ?)",
            features_to_save
        )
        return signal_id

def get_pending_signals(older_than_minutes=5):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, market, signal_type, entry_price FROM signal_logs WHERE is_correct = -1 AND timestamp < datetime('now', '-' || ? || ' minutes')",
            (older_than_minutes,)
        )
        return [{'id': r[0], 'market': r[1], 'signal': r[2], 'entry': r[3]} for r in cursor.fetchall()]

def update_signal_outcome(log_id, outcome_price, is_correct):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE signal_logs SET outcome_price = ?, is_correct = ? WHERE id = ?",
            (outcome_price, int(is_correct), log_id)
        )

def get_recent_accuracy(limit=100):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT AVG(is_correct) FROM (SELECT is_correct FROM signal_logs WHERE is_correct != -1 ORDER BY id DESC LIMIT ?)",
            (limit,)
        )
        result = cursor.fetchone()[0]
        return result if result is not None else 0.0

# **নতুন ফাংশন:** মডেল ট্রেনিংয়ের জন্য ফিচার ও ফলাফল নিয়ে আসা
def get_training_data(model_type, limit=10000):
    with sqlite3.connect(DB_FILE) as conn:
        query = f"""
            SELECT
                f.signal_id,
                f.feature_name,
                f.feature_value,
                s.is_correct
            FROM market_features f
            JOIN signal_logs s ON f.signal_id = s.id
            WHERE f.model_type = ? AND s.is_correct != -1
            ORDER BY f.signal_id DESC
            LIMIT ?;
        """
        df = pd.read_sql_query(query, conn, params=(model_type, limit))
        if df.empty:
            return pd.DataFrame(), pd.Series()
            
        # Pivot the dataframe to get features as columns
        features_df = df.pivot(index='signal_id', columns='feature_name', values='feature_value')
        # Get the target variable
        target_series = df.drop_duplicates(subset=['signal_id']).set_index('signal_id')['is_correct']
        return features_df, target_series

# --- User Management Functions (Unchanged) ---
# check_user_access, grant_access_to_user, etc. আগের মতোই থাকবে।
# আপনার দেওয়া কোড থেকে এই অংশটুকু কপি করে নিন।
def check_user_access(user_id: int, user_details: dict):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT has_access, is_banned FROM users WHERE user_id = ?", (user_id,))
    result = cursor.fetchone()
    is_new = False
    has_access = False
    is_banned = False

    if result is None:
        cursor.execute("INSERT INTO users (user_id, first_name, username) VALUES (?, ?, ?)",(user_id, user_details.get('first_name'), user_details.get('username')))
        conn.commit()
        is_new = True
    else:
        has_access = bool(result[0])
        is_banned = bool(result[1])
    conn.close()
    return has_access, is_new, is_banned

def grant_access_to_user(user_id: int):
    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()
    cursor.execute("UPDATE users SET has_access = 1, is_banned = 0 WHERE user_id = ?", (user_id,))
    conn.commit(); conn.close(); return True

def get_all_users():
    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()
    cursor.execute("SELECT user_id, first_name, has_access, is_banned FROM users")
    users = [{'id': r[0], 'name': r[1], 'access': bool(r[2]), 'banned': bool(r[3])} for r in cursor.fetchall()]
    conn.close(); return users

def set_ban_status(user_id: int, status: bool):
    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()
    cursor.execute("UPDATE users SET is_banned = ?, has_access = ? WHERE user_id = ?", (int(status), 0 if status else 1, user_id))
    conn.commit(); conn.close(); return True

def get_pending_users():
    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()
    cursor.execute("SELECT user_id, first_name FROM users WHERE has_access = 0 AND is_banned = 0")
    pending = [{'id': r[0], 'firstName': r[1]} for r in cursor.fetchall()]
    conn.close(); return pending

def add_api_key(api_key: str, user_id: int):
    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()
    try:
        cursor.execute("INSERT OR IGNORE INTO api_keys (key, added_by_user_id) VALUES (?, ?)", (api_key, user_id))
        conn.commit(); return True
    except sqlite3.Error: return False
    finally: conn.close()

def get_all_user_api_keys():
    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()
    cursor.execute("SELECT key FROM api_keys")
    keys = [row[0] for row in cursor.fetchall()]
    conn.close(); return keys