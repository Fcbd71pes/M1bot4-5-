# bot.py
import os
import asyncio
import logging
from threading import Thread
import time

from telegram.ext import Application, CommandHandler, CallbackQueryHandler, JobQueue

# কনফিগারেশন এবং মডিউল ইমপোর্ট
from config import TELEGRAM_BOT_TOKEN, ADMIN_USER_ID, MODEL_MACRO_PATH, MODEL_MICRO_PATH
import database
import analysis
from ml_model import train_and_evaluate_model
from handlers import (
    start_command, autosignal_command, button_handler, stopsignal_command, addkey_command,
    approve_command, pending_command, users_command, ban_command, unban_command
)

# লগিং সেটআপ
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# --- ব্যাকগ্রাউন্ড জব ফাংশন ---

async def check_signal_outcomes_job(context: object):
    """লগ করা সিগন্যালের ফলাফল যাচাই করে।"""
    logger.info("[JOB] Checking signal outcomes...")
    pending_signals = database.get_pending_signals(older_than_minutes=5)
    for signal in pending_signals:
        try:
            latest_data = await analysis.fetch_market_data(signal['market'], '1min', 1)
            if latest_data is not None and not latest_data.empty:
                outcome_price = latest_data.iloc[-1]['close']
                is_correct = (signal['signal'] == 'CALL' and outcome_price > signal['entry']) or \
                             (signal['signal'] == 'PUT' and outcome_price < signal['entry'])
                database.update_signal_outcome(signal['id'], outcome_price, is_correct)
                logger.info(f"Outcome for signal {signal['id']} updated. Correct: {is_correct}")
        except Exception as e:
            logger.error(f"Error checking outcome for signal {signal['id']}: {e}", exc_info=True)

def auto_retraining_task():
    """মডেল ট্রেনিংয়ের জন্য একটি আলাদা থ্রেডে চালানোর ফাংশন।"""
    logger.info("--- Starting Auto-Retraining Thread ---")
    
    # প্রথমে ম্যাক্রো মডেল
    train_and_evaluate_model('macro', MODEL_MACRO_PATH)
    time.sleep(5) # ছোট বিরতি
    
    # তারপর মাইক্রো মডেল
    train_and_evaluate_model('micro', MODEL_MICRO_PATH)
    
    logger.info("--- Auto-Retraining Thread Finished ---")
    
    # এই ফাংশনটি যেহেতু আলাদা থ্রেডে চলছে, asyncio এবং context এখানে সরাসরি ব্যবহার করা যাবে না।
    # অ্যাডমিনকে নোটিফিকেশন পাঠানোর জন্য একটি ছোট, সিঙ্ক্রোনাস HTTP রিকোয়েস্ট ব্যবহার করা যেতে পারে,
    # অথবা মূল asyncio লুপে একটি টাস্ক যোগ করা যেতে পারে। আপাতত আমরা শুধু লগ করছি।

async def schedule_auto_retraining_job(context: object):
    """মডেলের পারফর্মেন্স চেক করে এবং প্রয়োজন হলে পুনঃপ্রশিক্ষণ একটি আলাদা থ্রেডে শুরু করে।"""
    logger.info("[JOB] Checking model performance for potential retraining...")
    accuracy = database.get_recent_accuracy(limit=100)
    logger.info(f"Recent model accuracy (last 100 signals): {accuracy:.2%}")
    
    if accuracy < 0.55: # অ্যাকুরেসি ৫৫% এর নিচে নামলে
        logger.warning("Accuracy is below threshold. Triggering auto-retraining in a separate thread.")
        
        # ট্রেনিংকে একটি নতুন থ্রেডে চালানো হচ্ছে যাতে বট ব্লক না হয়
        training_thread = Thread(target=auto_retraining_task)
        training_thread.start()
        
        await context.bot.send_message(
            chat_id=ADMIN_USER_ID,
            text=f"🤖 Accuracy dropped to {accuracy:.2%}. Auto-retraining started in the background."
        )

def pre_run_checks():
    """বট শুরু করার আগে প্রয়োজনীয় ফাইল ও ডেটা আছে কিনা তা যাচাই করে।"""
    logger.info("Performing pre-run checks...")
    database.initialize_database()
    analysis.load_api_keys()
    
    # যদি মডেল ফাইল না থাকে, তাহলে একটি বেসিক মডেল তৈরির চেষ্টা করা যেতে পারে,
    # অথবা অ্যাডমিনকে একটি ওয়ার্নিং দেওয়া যেতে পারে।
    if not os.path.exists(MODEL_MACRO_PATH) or not os.path.exists(MODEL_MICRO_PATH):
        logger.warning("One or more model files are missing. The bot might not provide signals until trained.")
        logger.warning("Please ensure the bot runs for a while to collect data and trigger auto-retraining.")
        # এখানে আপনি একটি প্রাথমিক ট্রেনিং ম্যানুয়ালি ট্রিগার করার অপশন রাখতে পারেন।

def main():
    pre_run_checks()
    
    application = Application.builder().token(TELEGRAM_BOT_TOKEN).job_queue(JobQueue()).build()
    job_queue = application.job_queue
    
    # --- জব শিডিউল করা ---
    # প্রতি ৫ মিনিটে ফলাফল যাচাই
    job_queue.run_repeating(check_signal_outcomes_job, interval=300, first=60)
    # প্রতি ৬ ঘন্টায় একবার পুনঃপ্রশিক্ষণ চেক
    job_queue.run_repeating(schedule_auto_retraining_job, interval=21600, first=120)

    # --- হ্যান্ডলার যোগ করা ---
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("autosignal", autosignal_command))
    application.add_handler(CommandHandler("stopsignal", stopsignal_command))
    application.add_handler(CommandHandler("addkey", addkey_command))
    application.add_handler(CommandHandler("approve", approve_command))
    application.add_handler(CommandHandler("pending", pending_command))
    application.add_handler(CommandHandler("users", users_command))
    application.add_handler(CommandHandler("ban", ban_command))
    application.add_handler(CommandHandler("unban", unban_command))
    application.add_handler(CallbackQueryHandler(button_handler))

    logger.info("Bot with auto-learning capabilities is starting...")
    application.run_polling()

if __name__ == "__main__":
    main()